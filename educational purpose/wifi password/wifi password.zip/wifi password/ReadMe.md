# Wifi Password (Educational Purpose)


### See in [Instagram](https://www.instagram.com/) video

#### if we run this python file. it will create a password.txt file in your current directory.

### REQUIREMENT:
- Download [Python](https://python.org) latest version.


### PROCEDURE:
- Download the zip folder from Github and unzip it
Here is the link to download zip 👉
<a href='https://github.com/YezGotIt/source-code/raw/main/educational%20purpose/wifi password/wifi password.zip'>HERE</a>
- Open the folder in VS Code

- RUN, this command given below :
```
python password.py
```

---

### Disclaimer:

 #### Use this code has an educational purpose only.<img src="https://i.ibb.co/6sKk5rS/8d34dccac3830875b9b7beeaddd39c34-w-1898-64.png" width="20" height="20" />